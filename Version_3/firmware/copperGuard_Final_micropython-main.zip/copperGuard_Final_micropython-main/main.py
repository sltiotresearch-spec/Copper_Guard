# main.py
import ujson
import time
import machine
from machine import Pin, UART

# Try to import config‐server mode
try:
    from config_server import run_config
    HAS_CONFIG_SERVER = True
except ImportError:
    HAS_CONFIG_SERVER = False

# Load configuration
try:
    with open("config.json", "r") as f:
        cfg = ujson.load(f)
except:
    cfg = {}

# Line enables & names
VIRT_DIP_ENABLED = [bool(cfg.get(f"line_{i}", False)) for i in range(1,9)]
LINE_NAMES       = [cfg.get(f"line_{i}_name", "")    for i in range(1,9)]

# Recipients
STATUS_NUMBERS    = cfg.get("status_sms_recipients", []) or []
EMERGENCY_NUMBERS = cfg.get("emergency_recipients", [])  or []
CALL_NUMBERS      = cfg.get("call_alert_numbers", [])   or []

# Device info
DEVICE_NAME = cfg.get("device_name", "unknown")
LOCATION    = cfg.get("location", "unknown")

# Intervals
try:
    minutes = int(cfg.get("status_interval", "1"))
except:
    minutes = 1
STATUS_INTERVAL_MS = minutes * 60_000
SMS_INTERVAL_MS    = 10_000

# Max alert counts (only for emergency cut‐line alerts)
try:
    MAX_SMS_ALERTS  = int(cfg.get("max_sms_alerts",  "0"))
    MAX_CALL_ALERTS = int(cfg.get("max_call_alerts", "0"))
except:
    MAX_SMS_ALERTS = MAX_CALL_ALERTS = 0

# Counters & state for emergency alerts
sms_alert_count  = 0
call_alert_count = 0
prev_alert_flag  = False
last_alert_time  = 0
last_status_time = 0

# Hardware setup
BUTTON_PIN = 21
button_pin = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_UP)
opt_pins   = [Pin(p, Pin.IN,  Pin.PULL_UP) for p in (36,39,34,35,32,33,25,26)]
led_pins   = [Pin(p, Pin.OUT) for p in (27,14,12,13,15,2,4,18)]
error_led  = Pin(19, Pin.OUT)
sim_uart   = UART(2, baudrate=9600, tx=Pin(17), rx=Pin(16))

BLINK_INTERVAL_MS = 500
RX_TIMEOUT_MS     = 2000

def clear_rx_buffer():
    while sim_uart.any():
        sim_uart.read()

def check_sim800():
    clear_rx_buffer()
    sim_uart.write(b"AT\r\n")
    start = time.ticks_ms()
    buf = b""
    while time.ticks_diff(time.ticks_ms(), start) < RX_TIMEOUT_MS:
        if sim_uart.any():
            buf += sim_uart.read()
            if b"\r\nOK\r\n" in buf:
                clear_rx_buffer()
                return True
    clear_rx_buffer()
    return False

def send_sms_generic(numbers, text):
    """
    Send text to EVERY number in the list, waiting for '>' and then for 'OK' after each send.
    """
    # Put modem into SMS text mode once
    clear_rx_buffer()
    sim_uart.write(b"AT+CMGF=1\r\n")
    time.sleep_ms(200)

    for num in numbers:
        clear_rx_buffer()
        # tell modem who to send to
        sim_uart.write(b'AT+CMGS="' + num.encode() + b'"\r\n')

        # wait for '>' prompt
        start = time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(), start) < RX_TIMEOUT_MS:
            if sim_uart.any() and b'>' in sim_uart.read():
                break

        # send message + Ctrl-Z
        sim_uart.write(text.encode() + b"\r\n" + bytes([26]))

        # now wait for OK or ERROR before next number
        start = time.ticks_ms()
        buf = b""
        while time.ticks_diff(time.ticks_ms(), start) < (RX_TIMEOUT_MS * 5):
            if sim_uart.any():
                buf += sim_uart.read()
                if b"\r\nOK\r\n" in buf:
                    break
                if b"ERROR" in buf:
                    return False
        else:
            return False

    return True

def send_alert_sms(numbers, text):
    """Send emergency SMS, respecting MAX_SMS_ALERTS."""
    global sms_alert_count
    if MAX_SMS_ALERTS <= 0 or sms_alert_count < MAX_SMS_ALERTS:
        if send_sms_generic(numbers, text):
            sms_alert_count += 1
            return True
    return False

def send_call(numbers):
    """Send emergency calls, respecting MAX_CALL_ALERTS."""
    global call_alert_count
    if MAX_CALL_ALERTS <= 0 or call_alert_count < MAX_CALL_ALERTS:
        for num in numbers:
            clear_rx_buffer()
            sim_uart.write(b'ATD' + num.encode() + b';\r\n')
            time.sleep_ms(20000)
            sim_uart.write(b'ATH\r\n')
            time.sleep_ms(1000)
        call_alert_count += 1
        return True
    return False

def build_emergency_body(broken):
    body = f"ALERT: {DEVICE_NAME} @ {LOCATION}\nCut on:\n"
    for i in broken:
        name = LINE_NAMES[i] or f"Line {i+1}"
        body += f" - {name}\n"
    return body

def build_status_body(states):
    body = f"STATUS: {DEVICE_NAME} @ {LOCATION}\n"
    for i, st in enumerate(states):
        name = LINE_NAMES[i] or f"Line {i+1}"
        status = "DISABLED" if st is None else ("OK" if st else "CUT")
        body += f" - {name}: {status}\n"

    # Inform if emergency limits have been reached
    limits_hit = []
    if MAX_SMS_ALERTS > 0 and sms_alert_count >= MAX_SMS_ALERTS:
        limits_hit.append(f"SMS alerts ({sms_alert_count}/{MAX_SMS_ALERTS})")
    if MAX_CALL_ALERTS > 0 and call_alert_count >= MAX_CALL_ALERTS:
        limits_hit.append(f"Call alerts ({call_alert_count}/{MAX_CALL_ALERTS})")
    if limits_hit:
        body += "\nALERT LIMITS REACHED:\n"
        for l in limits_hit:
            body += f" - {l}\n"
        body += "Send 'START' SMS to restart device.\n"

    return body

def check_for_start_command():
    clear_rx_buffer()
    sim_uart.write(b"AT+CMGF=1\r\n")
    time.sleep_ms(200)
    sim_uart.write(b'AT+CMGL="REC UNREAD"\r\n')
    time.sleep_ms(500)

    buf = b""
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < RX_TIMEOUT_MS:
        if sim_uart.any():
            buf += sim_uart.read()

    if b"START" in buf:
        sim_uart.write(b'AT+CMGD=1,3\r\n')
        time.sleep_ms(200)
        machine.reset()

def main():
    global prev_alert_flag, last_alert_time, last_status_time

    # LED self‐test
    error_led.on()
    for l in led_pins: l.on()
    time.sleep_ms(3000)
    error_led.off()
    for l in led_pins: l.off()

    # Wait for SIM ready
    while not check_sim800():
        error_led.on()
        time.sleep_ms(1000)
        error_led.off()

    # Boot notification
    send_sms_generic(STATUS_NUMBERS,
                     f"BOOT: {DEVICE_NAME} @ {LOCATION} started")

    last_status_time = time.ticks_ms()
    last_alert_time  = 0
    prev_alert_flag  = False
    blink_state      = False
    last_blink_time  = 0

    while True:
        # Check incoming START command
        check_for_start_command()

        now = time.ticks_ms()
        if time.ticks_diff(now, last_blink_time) >= BLINK_INTERVAL_MS:
            blink_state = not blink_state
            last_blink_time = now

        # Read each line
        alert_flag = False
        broken     = []
        states     = [None]*8
        for i in range(8):
            intact = not opt_pins[i].value()
            if VIRT_DIP_ENABLED[i]:
                if not intact:
                    alert_flag = True
                    broken.append(i)
                    states[i] = False
                    led_pins[i].value(blink_state)
                else:
                    states[i] = True
                    led_pins[i].value(1)
            else:
                states[i] = None
                led_pins[i].value(0)

        # New cut event → reset emergency counters
        if alert_flag and not prev_alert_flag:
            global sms_alert_count, call_alert_count
            sms_alert_count = call_alert_count = 0

        # Emergency alerts (SMS then call if needed)
        if alert_flag and time.ticks_diff(now, last_alert_time) >= SMS_INTERVAL_MS:
            if not send_alert_sms(EMERGENCY_NUMBERS, build_emergency_body(broken)):
                send_call(CALL_NUMBERS)
            last_alert_time = now

        # Periodic status SMS (always uses send_sms_generic)
        if time.ticks_diff(now, last_status_time) >= STATUS_INTERVAL_MS:
            if send_sms_generic(STATUS_NUMBERS, build_status_body(states)):
                last_status_time = now

        prev_alert_flag = alert_flag
        time.sleep_ms(100)

if __name__ == "__main__":
    if button_pin.value() == 0 and HAS_CONFIG_SERVER:
        run_config()
    else:
        main()

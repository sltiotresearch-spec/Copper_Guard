import network
import socket
import ujson
import machine

def start_ap():
    ap = network.WLAN(network.AP_IF)
    ap.active(True)
    ap.config(
        essid="CCT_Alert_Device_0003",
        authmode=network.AUTH_WPA2_PSK,
        password="0003digital"
    )
    ap.ifconfig(("192.168.1.1", "255.255.255.0", "192.168.1.1", "8.8.8.8"))

def load_config():
    try:
        with open("config.json", "r") as f:
            return ujson.loads(f.read())
    except:
        return {}

def save_config(cfg):
    try:
        with open("config.json", "w") as f:
            f.write(ujson.dumps(cfg))
    except Exception as e:
        print("Error saving config:", e)

def pct_decode(s):
    s = s.replace("+", " ")
    res = ""
    i = 0
    while i < len(s):
        if s[i] == "%" and i + 2 < len(s):
            try:
                byte = int(s[i + 1 : i + 3], 16)
                res += chr(byte)
                i += 3
            except:
                res += s[i]
                i += 1
        else:
            res += s[i]
            i += 1
    return res

def parse_query(qs):
    params = {}
    for pair in qs.split("&"):
        if "=" in pair:
            key, val = pair.split("=", 1)
            params[pct_decode(key)] = pct_decode(val)
    return params

def web_page(cfg, saved=False):
    # Basic fields
    device_name = cfg.get("device_name", "")
    location = cfg.get("location", "")
    status_list = ",".join(cfg.get("status_sms_recipients", []))
    emer_list   = ",".join(cfg.get("emergency_recipients", []))
    call_list   = ",".join(cfg.get("call_alert_numbers", []))
    interval    = cfg.get("status_interval", "")
    max_sms     = cfg.get("max_sms_alerts", "")
    max_call    = cfg.get("max_call_alerts", "")

    # Line toggles & names
    line_checks = {}
    line_names  = {}
    for i in range(1, 9):
        line_checks[i] = 'checked' if cfg.get(f"line_{i}", False) else ''
        line_names[i]  = cfg.get(f"line_{i}_name", "")

    alert_script = "<script>alert('Configuration saved');</script>" if saved else ""

    # Build toggles + name inputs
    toggles_html = ""
    for i in range(1, 9):
        toggles_html += f"""
      <div class="toggle-row">
        <label>Line {i} Enabled:</label>
        <label class="switch">
          <input type="checkbox" name="line_{i}" {line_checks[i]}>
          <span class="slider"></span>
        </label>
      </div>
      <label>Line {i} Name (optional):</label>
      <input type="text" name="line_{i}_name" value="{line_names[i]}" />
      """

    html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>SLT Digital Lab</title>
  <style>
    body {{ font-family: Arial, sans-serif; background-color: #f2f2f2; margin:0; padding:0 }}
    .container {{ max-width:400px; margin:20px auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.1) }}
    h1 {{ text-align:center; color:#333; }}
    label {{ display:block; font-weight:bold; margin:8px 0 4px; color:#555; }}
    input[type="text"], input[type="number"] {{ width:100%; padding:8px; margin-bottom:12px; border:1px solid #ccc; border-radius:4px; box-sizing:border-box; }}
    .switch {{ position:relative; display:inline-block; width:50px; height:24px; margin-right:10px; vertical-align:middle }}
    .switch input {{ display:none }}
    .slider {{ position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background:#ccc; transition:.4s; border-radius:24px }}
    .slider:before {{ position:absolute; content:""; height:18px; width:18px; left:3px; bottom:3px; background:white; transition:.4s; border-radius:50% }}
    input:checked + .slider {{ background:#4CAF50 }}
    input:checked + .slider:before {{ transform:translateX(26px) }}
    input[type="submit"] {{ background:#4CAF50; color:white; padding:12px; border:none; border-radius:4px; cursor:pointer; width:100%; }}
    input[type="submit"]:hover {{ background:#45a049 }}
  </style>
</head>
<body>
  {alert_script}
  <div class="container">
    <h1>Copper Guard</h1>
    <form action="/" method="get">
      <label>Device Name:</label>
      <input type="text" name="device_name" value="{device_name}" />

      <label>Location:</label>
      <input type="text" name="location" value="{location}" />

      <label>Status SMS Recipients<br />(comma-separated):</label>
      <input type="text" name="status_sms_recipients" value="{status_list}" />

      <label>Emergency SMS Recipients<br />(comma-separated):</label>
      <input type="text" name="emergency_recipients" value="{emer_list}" />

      <label>Call Alert Numbers<br />(comma-separated):</label>
      <input type="text" name="call_alert_numbers" value="{call_list}" />

      <label>Status SMS Interval (minutes):</label>
      <input type="number" name="status_interval" min="1" value="{interval}" />

      <label>Max SMS Alerts:</label>
      <input type="number" name="max_sms_alerts" min="0" value="{max_sms}" />

      <label>Max Call Alerts:</label>
      <input type="number" name="max_call_alerts" min="0" value="{max_call}" />

      {toggles_html}

      <input type="submit" value="Save Configuration" />
    </form>
  </div>
</body>
</html>"""
    return html

def run_server():
    addr = socket.getaddrinfo("0.0.0.0", 80)[0][-1]
    s = socket.socket()
    s.bind(addr)
    s.listen(1)
    while True:
        cl, addr = s.accept()
        cl_file = cl.makefile("rwb", 0)
        request_line = cl_file.readline()
        while True:
            h = cl_file.readline()
            if not h or h == b"\r\n": break

        path = request_line.decode().split(" ")[1]
        cfg = load_config()
        saved = False

        if "?" in path:
            _, qs = path.split("?", 1)
            qs = qs.split(" ")[0]
            params = parse_query(qs)
            new_cfg = {
                "device_name": params.get("device_name", ""),
                "location": params.get("location", ""),
                "status_sms_recipients": [p.strip() for p in params.get("status_sms_recipients", "").split(",") if p.strip()],
                "emergency_recipients": [p.strip() for p in params.get("emergency_recipients", "").split(",") if p.strip()],
                "call_alert_numbers": [p.strip() for p in params.get("call_alert_numbers", "").split(",") if p.strip()],
                "status_interval": params.get("status_interval", ""),
                "max_sms_alerts": params.get("max_sms_alerts", ""),
                "max_call_alerts": params.get("max_call_alerts", "")
            }
            # toggles + names
            for i in range(1, 9):
                new_cfg[f"line_{i}"] = True if f"line_{i}" in params else False
                new_cfg[f"line_{i}_name"] = params.get(f"line_{i}_name", "")
            save_config(new_cfg)
            cfg = new_cfg
            saved = True

        response = web_page(cfg, saved)
        cl.send(b"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n")
        cl.send(response.encode())
        cl.close()

def run_config():
    start_ap()
    run_server()

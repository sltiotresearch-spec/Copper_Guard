#ifndef OLED_H
#define OLED_H

#include <Arduino.h>

void init_oled();
void draw_banner();
void draw_frame(bool line_EN[4], bool line_ST[4], bool sim_ok, int signal_Level);
void config_oled();
void draw_boot_step(const char* currentTask, const char* history);

#endif

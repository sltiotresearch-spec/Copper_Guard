#include "oled.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define SCREEN_ADDRESS 0x3C
#define BANNER_HEIGHT 14

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
bool flash_ST = false;

// ================= INIT =================
void init_oled() {
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    while (1);
  }
  display.clearDisplay();
}

// ================= BANNER =================
void draw_banner() {
  display.fillRect(0, 0, SCREEN_WIDTH, BANNER_HEIGHT, WHITE);
  display.setTextColor(BLACK);
  display.setTextSize(1);
  display.setCursor(4, 4);
  display.print("COPPER GUARD PROJECT");
  display.setTextColor(WHITE);
  display.display();
}

// ================= MAIN FRAME =================
void draw_frame(bool line_EN[4], bool line_ST[4], bool sim_ok, int signal_Level) {
  display.fillRect(
    0,
    BANNER_HEIGHT,
    SCREEN_WIDTH,
    SCREEN_HEIGHT - BANNER_HEIGHT,
    BLACK
  );

  // ---- LINE STATUS ----
  int y_pos = BANNER_HEIGHT + 4;
  for (int i = 0; i < 4; i++) {
    display.setCursor(0, y_pos);
    display.print("L");
    display.print(i + 1);

    display.print(line_EN[i] ? " EN" : " --  --");
    display.print(line_EN[i] && line_ST[i] ? "  OK" : "");
    display.print(line_EN[i] && !line_ST[i] && flash_ST ? " CUT" : "");

    y_pos += 12;
  }

  // ---- DIVIDER ----
  display.drawLine(64, BANNER_HEIGHT, 64, SCREEN_HEIGHT, SSD1306_WHITE);

  // ---- SIM STATUS ----
  display.setCursor(70, BANNER_HEIGHT + 4);
  display.print("SiM  ");
  display.print(sim_ok ? "OK" : "");
  display.print(!sim_ok && flash_ST ? "ERR" : "");

  // ---- SIGNAL LEVEL ----
  display.setCursor(70, BANNER_HEIGHT + 16);
  display.print("SiG  ");
  display.print(signal_Level);

  // ---- RUN ANIMATION ----
  display.setCursor(96, BANNER_HEIGHT + 40);
  display.print(flash_ST ? "--" : "|");

  flash_ST = !flash_ST;
  display.display();
}

// ================= CONFIG SCREEN =================
void config_oled() {
  display.fillRect(
    0,
    BANNER_HEIGHT,
    SCREEN_WIDTH,
    SCREEN_HEIGHT - BANNER_HEIGHT,
    BLACK
  );
  display.setCursor(28, 24);
  display.print("Config Mode");
  display.setCursor(28, 36);
  display.print("192.168.1.1");
  display.display();
}

void draw_boot_step(const char* currentTask, const char* history) {
  display.clearDisplay();
  
  // 1. Yellow Header (Current Task)
  display.fillRect(0, 0, SCREEN_WIDTH, BANNER_HEIGHT, WHITE);
  display.setTextColor(BLACK);
  display.setCursor(4, 4);
  display.print("> ");
  display.print(currentTask);

  // 2. Blue Area (History/Done items)
  display.setTextColor(WHITE);
  display.setCursor(0, BANNER_HEIGHT + 10);
  display.print(history);
  
  display.display();
}

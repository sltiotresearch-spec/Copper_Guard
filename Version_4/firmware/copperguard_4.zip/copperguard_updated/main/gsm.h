#ifndef GSM_H
#define GSM_H

#include <Arduino.h>

// Initialize GSM module (set SMS mode, check connection)
bool init_gsm();

// Send an SMS to a specific number
bool send_sms(const char* number, const char* text);

// Make a call to a specific number
void make_call(const char* number);

#endif
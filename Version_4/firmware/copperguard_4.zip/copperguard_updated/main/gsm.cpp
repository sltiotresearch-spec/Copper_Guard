#include "gsm.h"

// Timeout definitions
#define GSM_TIMEOUT 2000

#define SMS_TIMEOUT 15000 // Increased to 15 seconds for stability

// Helper: Send AT command and wait for expected response
static bool sendAT(const char* cmd, const char* expected, unsigned long timeout) {
  // Clear buffer
  while (Serial.available()) Serial.read();

  Serial.println(cmd);

  unsigned long start = millis();
  String response = "";

  while (millis() - start < timeout) {
    while (Serial.available()) {
      char c = Serial.read();
      response += c;
      if (response.indexOf(expected) != -1) {
        return true;
      }
    }
    yield(); // Avoid watchdog reset
  }
  return false;
}

bool init_gsm() {
  delay(10000);
  // 1. Basic check
  if (!sendAT("AT", "OK", GSM_TIMEOUT)) return false;
  
  // 2. Set SMS to Text Mode
  if (!sendAT("AT+CMGF=1", "OK", GSM_TIMEOUT)) return false;

  // 3. Delete all old SMS to free up space (Optional, good practice)
  sendAT("AT+CMGDA=\"DEL ALL\"", "OK", GSM_TIMEOUT);
  
  return true;
}

bool send_sms(const char* number, const char* text) {
  // Clear any junk in the serial buffer first
  while(Serial.available()) Serial.read();

  String cmd = "AT+CMGS=\"";
  cmd += number;
  cmd += "\"";
  
  Serial.println(cmd);
  
  // Wait for the '>' prompt specifically (max 2 seconds)
  unsigned long waitStart = millis();
  bool foundPrompt = false;
  while(millis() - waitStart < 2000) {
    if(Serial.read() == '>') {
      foundPrompt = true;
      break;
    }
    yield();
  }

  Serial.print(text);
  Serial.write(26); // Send Ctrl+Z

  bool success = sendAT("", "OK", SMS_TIMEOUT);
  
  // If the transmission caused a voltage dip, the ESP might reboot here.
  // The capacitor mentioned in the Hardware Fix prevents this.
  return success;
}

void make_call(const char* number) {
  // Command: ATD+9477...;
  String cmd = "ATD";
  cmd += number;
  cmd += ";"; // Don't forget the semicolon for voice calls
  
  Serial.println(cmd);
  
  // Let it ring for 15 seconds then hang up
  // (You can adjust this delay or make it non-blocking later)
  delay(15000); 
  
  Serial.println("ATH"); // Hang up
}